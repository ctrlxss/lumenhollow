package com.lumenhollow;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1834;

public class DusksteelSwordItem extends class_1829 {
    public DusksteelSwordItem(class_1793 properties) {
        super(class_1834.field_22033, properties);
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        target.method_20803(40);
        return super.method_7873(stack, target, attacker);
    }
}
