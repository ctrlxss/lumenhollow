package com.lumenhollow;

import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModItems {
    public static final class_1792 LUMEN_CRYSTAL = registerItem("lumen_crystal", new class_1792(new class_1792.class_1793()));
    public static final class_1792 MOONFRUIT = registerItem("moonfruit", new class_1792(new class_1792.class_1793().method_19265(ModFoodComponents.MOONFRUIT)));
    public static final class_1792 ASTRAL_SHARD = registerItem("astral_shard", new class_1792(new class_1792.class_1793()));
    public static final class_1792 DUSKSTEEL_INGOT = registerItem("dusksteel_ingot", new class_1792(new class_1792.class_1793()));
    public static final class_1792 STARFIRE_CORE = registerItem("starfire_core", new class_1792(new class_1792.class_1793()));
    public static final class_1792 PRISM_STAFF = registerItem("prism_staff", new PrismStaffItem(new class_1792.class_1793().method_7889(1).method_7895(256)));
    public static final class_1792 DUSKSTEEL_SWORD = registerItem("dusksteel_sword", new DusksteelSwordItem(new class_1792.class_1793().method_7889(1).method_7895(1024)));

    public static final class_1747 LUMEN_CRYSTAL_BLOCK_ITEM = registerBlockItem("lumen_crystal_block", ModBlocks.LUMEN_CRYSTAL_BLOCK);
    public static final class_1747 LUMEN_PORTAL_ITEM = registerBlockItem("lumen_portal", ModBlocks.LUMEN_PORTAL_BLOCK);
    public static final class_1747 LUMEN_CRYSTAL_ORE_ITEM = registerBlockItem("lumen_crystal_ore", ModBlocks.LUMEN_CRYSTAL_ORE);
    public static final class_1747 LUMEN_LANTERN_ITEM = registerBlockItem("lumen_lantern", ModBlocks.LUMEN_LANTERN);

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(LumenHollowMod.MOD_ID, name), item);
    }

    private static class_1747 registerBlockItem(String name, net.minecraft.class_2248 block) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(LumenHollowMod.MOD_ID, name), new class_1747(block, new class_1792.class_1793()));
    }

    public static void register() {
    }
}
