package com.lumenhollow;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3965;

public class LumenPortalBlock extends class_2248 {
    public LumenPortalBlock(class_2251 properties) {
        super(properties);
    }

    public class_1269 use(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        return handleUse(state, level, pos, player, hand, hitResult);
    }

    public class_1269 onUse(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        return handleUse(state, level, pos, player, hand, hitResult);
    }

    private class_1269 handleUse(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        if (!level.field_9236 && player instanceof class_3222 serverPlayer) {
            class_3218 targetWorld = serverPlayer.field_13995.method_3847(ModDimensions.LUMEN_HOLLOW);
            if (targetWorld != null) {
                serverPlayer.method_14251(targetWorld, pos.method_10263() + 0.5, targetWorld.method_31607() + 8, pos.method_10260() + 0.5, player.method_36454(), player.method_36455());
                serverPlayer.method_5783(class_3417.field_19197, 1.0f, 1.2f);
                serverPlayer.method_6092(new class_1293(class_1294.field_5925, 300, 0, false, false));
            }
        }
        return class_1269.method_29236(level.field_9236);
    }
}
