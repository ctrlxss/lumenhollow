package com.lumenhollow;

import net.minecraft.class_4174;

public final class ModFoodComponents {
    public static final class_4174 MOONFRUIT = new class_4174.class_4175()
            .method_19238(4)
            .method_19237(1.2f)
            .method_19242();

    private ModFoodComponents() {
    }
}
