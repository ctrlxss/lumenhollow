package com.lumenhollow;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class PrismStaffItem extends class_1792 {
    public PrismStaffItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (!level.field_9236) {
            player.method_7357().method_7906(this, 20);
            player.method_31548().method_7398(new class_1799(ModItems.ASTRAL_SHARD));
        }
        return class_1271.method_29237(stack, level.field_9236);
    }
}
