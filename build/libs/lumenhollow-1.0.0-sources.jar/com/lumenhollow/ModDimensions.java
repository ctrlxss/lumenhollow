package com.lumenhollow;

import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public final class ModDimensions {
    public static final class_5321<class_1937> LUMEN_HOLLOW = class_5321.method_29179(class_7924.field_41223, class_2960.method_60655(LumenHollowMod.MOD_ID, "lumen_hollow"));

    public static void register() {
    }
}
