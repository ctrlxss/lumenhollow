package com.lumenhollow;

import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public final class ModBlocks {
    public static final class_2248 LUMEN_CRYSTAL_BLOCK = registerBlock("lumen_crystal_block",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16024)
                    .method_9629(3.0f, 6.0f)
                    .method_9626(class_2498.field_27197)
                    .method_9631(state -> 12)));

    public static final class_2248 LUMEN_PORTAL_BLOCK = registerBlock("lumen_portal",
            new LumenPortalBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16014)
                    .method_9632(2.0f)
                    .method_9626(class_2498.field_11537)
                    .method_22488()
                    .method_9631(state -> 10)));

    public static final class_2248 LUMEN_CRYSTAL_ORE = registerBlock("lumen_crystal_ore",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16026)
                    .method_9629(4.5f, 8.0f)
                    .method_9626(class_2498.field_11544)
                    .method_9631(state -> 4)));

    public static final class_2248 LUMEN_LANTERN = registerBlock("lumen_lantern",
            new LumenLanternBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16010)
                    .method_9632(1.5f)
                    .method_9626(class_2498.field_11537)
                    .method_22488()
                    .method_9631(state -> 15)));

    private static class_2248 registerBlock(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(LumenHollowMod.MOD_ID, name), block);
    }

    public static void register() {
    }
}
