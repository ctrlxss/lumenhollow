package com.lumenhollow;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public class LumenLanternBlock extends class_2248 {
    public LumenLanternBlock(class_2251 properties) {
        super(properties);
    }

    public class_1269 use(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        return class_1269.method_29236(level.field_9236);
    }
}
